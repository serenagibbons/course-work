﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibrary;
using System.Data.SqlClient;
using Microsoft.Win32;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Collections;

namespace CourseWorkGUIv2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        CourseWork courseWork;

        string connString = @"server=(LocalDB)\MSSQLLocalDB;" +
                "database=CourseWork;" +
                "Trusted_Connection=True;";

        //*****************************************************************************
        // Method: MainWindow
        //
        // Purpose: Initialize main window
        //*****************************************************************************
        public MainWindow()
        {
            InitializeComponent();
        }

        //*****************************************************************************
        // Method: Window_Loaded
        //
        // Purpose: Populates the submissions ListBox with data from the SQL Server 
        // database when the window is loaded
        //*****************************************************************************
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayData();
        }

        //*****************************************************************************
        // Method: DisplayData
        //
        // Purpose: Reads in data from the database and displays it in the submission
        // list box
        //*****************************************************************************
        private void DisplayData()
        {
            SqlConnection sqlConn;
            sqlConn = new SqlConnection(connString);
            sqlConn.Open(); // Open the connection
            
            // Setup the SQL command
            string sql = "SELECT * FROM Submission";
            SqlCommand command = new SqlCommand(sql, sqlConn);

            // Retrieve the data from the database
            SqlDataReader reader = command.ExecuteReader();


            // remove all items from listbox
            while (submissionListBox.Items.Count > 0)
            {
                submissionListBox.Items.RemoveAt(0);
            }
            // Associate the ListBox with the SqlDataReader, this will automatically populate the ListBox.
            submissionListBox.ItemsSource = reader;
            while (reader.Read())
            {
                object assign = reader["AssignmentName"];
                submissionListBox.Items.Add(assign.ToString());
            }
          
        }

        //*****************************************************************************
        // Method: AddData
        //
        // Purpose: Reads in data from the CourseWork object into the database
        //*****************************************************************************
        private void AddData(CourseWork c)
        {
            for (int i = 0; i < c.Submissions.Count; ++i)
            {
                // sql insert statement to insert input fields into new row
                string insert = "INSERT INTO Submission (AssignmentName, CategoryName, Grade)" +
                    "VALUES ('" + c.Submissions[i].AssignmentName + "', '" + c.Submissions[i].CategoryName + "', '" + c.Submissions[i].Grade + "');";

                SqlConnection sqlConn;
                sqlConn = new SqlConnection(connString);
                sqlConn.Open();

                SqlCommand command = new SqlCommand(insert, sqlConn);
                int rowsAffected = command.ExecuteNonQuery();
            }

        }
        //*****************************************************************************
        // Method: ExitMenu_Handler
        //
        // Purpose: Close the window
        //*****************************************************************************
        private void ExitMenu_Handler(object sender, RoutedEventArgs e)
        {
            Close();
        }

        //*****************************************************************************
        // Method: AboutMenu_Handler
        //
        // Purpose: Display a pop up message about the program
        //*****************************************************************************
        private void AboutMenu_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Course Work GUI\n" +
                "Version 2.0\n" +
                "Written by Serena Gibbons");
        }

        //*****************************************************************************
        // Method: ImportItem_Handler
        //
        // Purpose: Reads course work data from the selected course work JSON file 
        // into the database
        //*****************************************************************************
        private void ImportItem_Click(object sender, RoutedEventArgs e)
        {
          
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Directory.GetCurrentDirectory();
            openFileDialog.Filter = "JSON files (*.json)|*.json";
            if (openFileDialog.ShowDialog() == true)
            {
                string fileName = openFileDialog.FileName;

                // instantiate couseWork
                courseWork = new CourseWork();

                // try reading from file, if exception thrown, break
                try
                {
                    FileStream reader = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                    DataContractJsonSerializer input;
                    input = new DataContractJsonSerializer(typeof(CourseWork));
                    courseWork = (CourseWork)input.ReadObject(reader);
                    reader.Close();
                }
                catch (IOException)
                {
                    Console.WriteLine("Invalid file name.\n");
                    return;
                }

                // remove all items from listbox
                while (submissionListBox.Items.Count > 0)
                {
                    submissionListBox.Items.RemoveAt(0);
                }
              
                AddData(courseWork);
            }
        }

        //*****************************************************************************
        // Method: SubmissionListBox_SelectionChanged
        //
        // Purpose: Display appropriate data when a submission is selected in the 
        // submission ListBox.
        //*****************************************************************************
        private void SubmissionListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // clear textboxes
            assignmentTextBox.Clear();
            categoryTextBox.Clear();
            gradeTextBox.Clear();

            // get the item selected
            IList items = (IList)e.AddedItems;

            // cast as a submission object
            string str = (string)items[0];
            //Submission s = (Submission)items[0];

            ShowSubmissionDetails(str);
        }

        private void ShowSubmissionDetails(string str)
        {
            Submission s = courseWork.FindSubmission(str);

            // set text fields
            assignmentTextBox.Text = s.AssignmentName;
            categoryTextBox.Text = s.CategoryName;
            gradeTextBox.Text = s.Grade.ToString();
        }
    }
}